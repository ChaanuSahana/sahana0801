"""Convenience entry point.

All of these work from the project folder:
    python main.py
    uvicorn main:app --reload
    uvicorn app.main:app --reload
"""
from app.main import app  # noqa: F401  (re-exported so "uvicorn main:app" works)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
