"""SQLite persistence with SQLAlchemy: models plus small helper functions."""
from datetime import datetime, timezone
from typing import Iterator, List, Optional

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String, Text, create_engine, select
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    Session,
    mapped_column,
    relationship,
    selectinload,
    sessionmaker,
)

from . import config
from .schemas import UserInput


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    user_id: Mapped[str] = mapped_column(String(50), primary_key=True)
    username: Mapped[str] = mapped_column(String(80))
    age: Mapped[int] = mapped_column(Integer)
    weight: Mapped[float] = mapped_column(Float)
    goal: Mapped[str] = mapped_column(String(60))
    intensity: Mapped[str] = mapped_column(String(10))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    plan: Mapped[Optional["Plan"]] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )


class Plan(Base):
    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(
        String(50), ForeignKey("users.user_id", ondelete="CASCADE"), unique=True
    )
    original_plan: Mapped[str] = mapped_column(Text)
    updated_plan: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    nutrition_tip: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    feedback: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow)

    user: Mapped["User"] = relationship(back_populates="plan")


_connect_args = {"check_same_thread": False} if config.DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(config.DATABASE_URL, connect_args=_connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def init_db() -> None:
    """Create the tables if they do not exist yet."""
    Base.metadata.create_all(bind=engine)


def get_db() -> Iterator[Session]:
    """FastAPI dependency: one database session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------------------------------------------------------------- users ---
def save_user(db: Session, data: UserInput) -> User:
    """Create the user, or update the details if this user_id already exists."""
    user = db.get(User, data.user_id)
    if user is None:
        user = User(user_id=data.user_id)
        db.add(user)
    user.username = data.username
    user.age = data.age
    user.weight = data.weight
    user.goal = data.goal
    user.intensity = data.intensity
    db.commit()
    db.refresh(user)
    return user


def get_user(db: Session, user_id: str) -> Optional[User]:
    return db.get(User, user_id)


def get_all_users(db: Session) -> List[User]:
    stmt = select(User).options(selectinload(User.plan)).order_by(User.created_at.desc())
    return list(db.scalars(stmt).all())


def delete_user(db: Session, user_id: str) -> bool:
    user = db.get(User, user_id)
    if user is None:
        return False
    db.delete(user)  # the plan is removed by the ORM cascade
    db.commit()
    return True


# ---------------------------------------------------------------- plans ---
def get_plan(db: Session, user_id: str) -> Optional[Plan]:
    return db.scalar(select(Plan).where(Plan.user_id == user_id))


def get_all_plans(db: Session) -> List[Plan]:
    return list(db.scalars(select(Plan).order_by(Plan.created_at.desc())).all())


def save_plan(db: Session, user_id: str, workout_plan: str, nutrition_tip: Optional[str] = None) -> Plan:
    """Store a freshly generated plan. Any earlier update/feedback is cleared."""
    plan = get_plan(db, user_id)
    if plan is None:
        plan = Plan(user_id=user_id, original_plan=workout_plan)
        db.add(plan)
    else:
        plan.original_plan = workout_plan
        plan.updated_plan = None
        plan.feedback = None
    plan.nutrition_tip = nutrition_tip
    db.commit()
    db.refresh(plan)
    return plan


def update_plan(
    db: Session,
    user_id: str,
    updated_plan: str,
    feedback: str,
    nutrition_tip: Optional[str] = None,
) -> Optional[Plan]:
    """Store the feedback-based revision next to the untouched original plan."""
    plan = get_plan(db, user_id)
    if plan is None:
        return None
    plan.updated_plan = updated_plan
    plan.feedback = feedback
    if nutrition_tip:
        plan.nutrition_tip = nutrition_tip
    db.commit()
    db.refresh(plan)
    return plan


def save_tip(db: Session, user_id: str, nutrition_tip: str) -> Optional[Plan]:
    plan = get_plan(db, user_id)
    if plan is None:
        return None
    plan.nutrition_tip = nutrition_tip
    db.commit()
    db.refresh(plan)
    return plan


def get_original_plan(db: Session, user_id: str) -> Optional[str]:
    plan = get_plan(db, user_id)
    return plan.original_plan if plan else None


def get_current_plan(db: Session, user_id: str) -> Optional[str]:
    """The latest version of the plan: the updated one if it exists, else the original."""
    plan = get_plan(db, user_id)
    if plan is None:
        return None
    return plan.updated_plan or plan.original_plan
