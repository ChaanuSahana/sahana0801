"""Pydantic schemas used to validate form and API input."""
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

GOALS = ["weight loss", "muscle gain", "general wellness", "flexibility", "endurance"]
INTENSITIES = ["low", "medium", "high"]


class UserInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    username: str = Field(min_length=1, max_length=80)
    user_id: str = Field(min_length=1, max_length=50, pattern=r"^[A-Za-z0-9_.\-]+$")
    age: int = Field(ge=12, le=100)
    weight: float = Field(gt=25, le=300)
    goal: Literal["weight loss", "muscle gain", "general wellness", "flexibility", "endurance"]
    intensity: Literal["low", "medium", "high"]

    @field_validator("goal", "intensity", mode="before")
    @classmethod
    def _normalise_choice(cls, value):
        return value.strip().lower() if isinstance(value, str) else value

    @field_validator("username", mode="after")
    @classmethod
    def _single_line_name(cls, value: str) -> str:
        # Collapse tabs/newlines so a name can never break the AI prompt layout.
        return " ".join(value.split())


class FeedbackRequest(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    user_id: str = Field(min_length=1, max_length=50, pattern=r"^[A-Za-z0-9_.\-]+$")
    feedback: str = Field(min_length=3, max_length=500)


class PlanResponse(BaseModel):
    """JSON shape returned by the /api endpoints."""

    user_id: str
    username: str
    age: int
    weight: float
    goal: str
    intensity: str
    workout_plan: str
    original_plan: str
    updated: bool
    nutrition_tip: Optional[str] = None


_FIELD_MESSAGES = {
    "username": "Enter your name (up to 80 characters).",
    "user_id": "Use 1 to 50 letters, numbers, dots, dashes or underscores for the User ID.",
    "age": "Enter an age between 12 and 100.",
    "weight": "Enter a weight between 25 and 300 kg.",
    "goal": "Choose one of the listed fitness goals.",
    "intensity": "Choose low, medium or high intensity.",
    "feedback": "Write between 3 and 500 characters of feedback.",
}


def format_validation_errors(exc: ValidationError) -> List[str]:
    """Turn a Pydantic error into short, readable messages (one per field)."""
    messages: List[str] = []
    for err in exc.errors():
        loc = err.get("loc") or ()
        field = str(loc[-1]) if loc else ""
        message = _FIELD_MESSAGES.get(field, "Check the value you entered.")
        if message not in messages:
            messages.append(message)
    return messages
