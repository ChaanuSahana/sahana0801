"""Shared Gemini helper: one client, retries, friendly errors, plain-text clean-up."""
import logging
import re
import time
from typing import Optional

from . import config

logger = logging.getLogger("fitbuddy.gemini")

RETRYABLE_CODES = {429, 500, 502, 503, 504}
_client = None


class AIServiceError(Exception):
    """Raised when Gemini cannot produce a usable answer. The message is safe to show to users."""


def get_client():
    """Create the Gemini client on first use, so the app can start even without a key."""
    global _client
    if not config.GOOGLE_API_KEY:
        raise AIServiceError(
            "The Gemini API key is missing. Add GOOGLE_API_KEY to the .env file, save it, "
            "and restart the server."
        )
    if _client is None:
        from google import genai
        from google.genai import types

        _client = genai.Client(
            api_key=config.GOOGLE_API_KEY,
            http_options=types.HttpOptions(timeout=90_000),  # milliseconds
        )
    return _client


def _friendly_message(exc) -> str:
    code = getattr(exc, "code", None)
    detail = (getattr(exc, "message", None) or str(exc) or "").lower()
    if code in (401, 403) or "api key" in detail:
        return "Gemini rejected the API key. Check GOOGLE_API_KEY in your .env file."
    if code == 404:
        return (
            "Gemini could not find the configured model. "
            "Check GEMINI_PLAN_MODEL and GEMINI_TIP_MODEL in your .env file."
        )
    if code == 429:
        return "The Gemini usage limit was reached. Wait a minute and try again."
    if code in RETRYABLE_CODES:
        return "The Gemini service is busy right now. Please try again in a moment."
    return "Gemini could not complete the request. Please try again."


def generate_text(
    *,
    model: str,
    prompt: str,
    system_instruction: Optional[str] = None,
    temperature: float = 0.7,
    max_output_tokens: int = 4096,
    attempts: int = 3,
) -> str:
    """Send one prompt to Gemini and return cleaned plain text."""
    client = get_client()
    from google.genai import errors, types

    cfg = types.GenerateContentConfig(
        system_instruction=system_instruction,
        temperature=temperature,
        max_output_tokens=max_output_tokens,
    )

    for attempt in range(1, attempts + 1):
        try:
            response = client.models.generate_content(model=model, contents=prompt, config=cfg)
        except errors.APIError as exc:
            code = getattr(exc, "code", None)
            logger.warning("Gemini API error (attempt %s/%s): %s", attempt, attempts, exc)
            if code in RETRYABLE_CODES and attempt < attempts:
                time.sleep(2 ** attempt)
                continue
            raise AIServiceError(_friendly_message(exc)) from exc
        except Exception as exc:  # network problems, timeouts, SDK errors
            logger.warning("Gemini request failed (attempt %s/%s): %s", attempt, attempts, exc)
            if attempt < attempts:
                time.sleep(2 ** attempt)
                continue
            raise AIServiceError(
                "Could not reach Gemini. Check your internet connection and try again."
            ) from exc

        text = (getattr(response, "text", None) or "").strip()
        if text:
            return clean_text(text)
        logger.warning("Gemini returned an empty response (attempt %s/%s)", attempt, attempts)

    raise AIServiceError("Gemini returned an empty answer. Please try again.")


def clean_text(text: str) -> str:
    """Strip Markdown symbols so the answer reads well inside a plain <pre> block."""
    cleaned = []
    for line in text.replace("\r\n", "\n").split("\n"):
        line = line.rstrip()
        if re.fullmatch(r"\s*([-*_])\1{2,}\s*", line):  # horizontal rules
            continue
        line = re.sub(r"^\s{0,3}#{1,6}\s*", "", line)  # headings
        line = re.sub(r"^(\s*)[*\-]\s+", r"\1• ", line)  # bullets
        line = line.replace("**", "").replace("__", "")  # bold
        line = re.sub(r"(?<![\w*])\*(?!\s)([^*\n]+?)\*(?![\w*])", r"\1", line)  # italics
        cleaned.append(line)
    return re.sub(r"\n{3,}", "\n\n", "\n".join(cleaned)).strip()
