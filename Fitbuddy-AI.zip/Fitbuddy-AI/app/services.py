"""Business logic shared by the HTML routes and the JSON API."""
import logging
from typing import Tuple

from sqlalchemy.orm import Session

from . import database as db_layer
from .database import Plan, User
from .gemini_client import AIServiceError
from .gemini_flash_generator import FALLBACK_TIPS, generate_nutrition_tip_with_flash
from .gemini_generator import generate_workout_gemini
from .schemas import FeedbackRequest, PlanResponse, UserInput
from .updated_plan import update_workout_plan

logger = logging.getLogger("fitbuddy.services")


class UserNotFoundError(Exception):
    """No plan exists yet for the given user_id."""


def _tip_or_fallback(goal: str, intensity: str, previous_tip: str = None) -> str:
    """A tip is a bonus: if the tip model fails, fall back to a built-in tip."""
    try:
        return generate_nutrition_tip_with_flash(goal, intensity, previous_tip)
    except AIServiceError as exc:
        logger.warning("Using fallback nutrition tip: %s", exc)
        return FALLBACK_TIPS.get(goal, FALLBACK_TIPS["general wellness"])


def create_workout_plan(db: Session, data: UserInput) -> Tuple[User, Plan]:
    """Generate the plan and tip first, then save, so a failed AI call leaves no half-saved user."""
    workout_plan = generate_workout_gemini(
        data.username, data.age, data.weight, data.goal, data.intensity
    )
    tip = _tip_or_fallback(data.goal, data.intensity)
    user = db_layer.save_user(db, data)
    plan = db_layer.save_plan(db, data.user_id, workout_plan, tip)
    return user, plan


def apply_feedback(db: Session, data: FeedbackRequest) -> Tuple[User, Plan]:
    """Revise the user's latest plan using their feedback."""
    user = db_layer.get_user(db, data.user_id)
    plan = db_layer.get_plan(db, data.user_id)
    if user is None or plan is None:
        raise UserNotFoundError(data.user_id)

    current = plan.updated_plan or plan.original_plan
    revised = update_workout_plan(current, data.feedback, user.goal, user.intensity, user.age)
    tip = _tip_or_fallback(user.goal, user.intensity, plan.nutrition_tip)
    plan = db_layer.update_plan(db, data.user_id, revised, data.feedback, tip)
    return user, plan


def refresh_tip(db: Session, user_id: str) -> Tuple[User, Plan]:
    """Generate a different nutrition or recovery tip for an existing user."""
    user = db_layer.get_user(db, user_id)
    plan = db_layer.get_plan(db, user_id)
    if user is None or plan is None:
        raise UserNotFoundError(user_id)
    tip = generate_nutrition_tip_with_flash(user.goal, user.intensity, plan.nutrition_tip)
    plan = db_layer.save_tip(db, user_id, tip)
    return user, plan


def to_plan_response(user: User, plan: Plan) -> PlanResponse:
    return PlanResponse(
        user_id=user.user_id,
        username=user.username,
        age=user.age,
        weight=user.weight,
        goal=user.goal,
        intensity=user.intensity,
        workout_plan=plan.updated_plan or plan.original_plan,
        original_plan=plan.original_plan,
        updated=bool(plan.updated_plan),
        nutrition_tip=plan.nutrition_tip,
    )
