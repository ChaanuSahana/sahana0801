"""Workout plan generation (Gemini plan model)."""
from . import config
from .gemini_client import generate_text

SYSTEM_INSTRUCTION = (
    "You are FitBuddy, an experienced certified personal trainer. "
    "You write safe, realistic, easy-to-follow training plans in plain text. "
    "Never use Markdown symbols such as #, * or **."
)

PLAN_FORMAT = """\
Day 1 - <focus of the day>
Warm-up (5-10 min): <what to do>
Main workout:
  1. <exercise> - <sets> x <reps or duration> (rest <seconds>)
  2. ...
Cooldown / recovery: <what to do>

Day 2 - <focus of the day>
...
(continue until Day 7)

Safety note: <one short sentence>"""


def generate_workout_gemini(username: str, age: int, weight: float, goal: str, intensity: str) -> str:
    """Return a structured 7-day workout plan as plain text."""
    prompt = f"""Create a personalised 7-day workout plan for this person.

Name: {username}
Age: {age}
Weight: {weight:g} kg
Fitness goal: {goal}
Preferred intensity: {intensity}

Rules:
- Write exactly 7 days, labelled Day 1 to Day 7, and follow the format below exactly.
- Match the goal "{goal}" in exercise choice, volume and structure.
- Intensity guide: low = 3 training days, gentle progression; medium = 4 or 5 training days;
  high = 5 or 6 training days, harder sets. Fill the other days with rest or light recovery
  (walking, stretching, mobility) and say so on that day.
- Every training day needs a warm-up (5-10 minutes), a main workout with exercises,
  sets and reps (or durations) and rest times, and a cooldown or recovery tip.
- Use bodyweight moves and basic equipment (dumbbells, resistance bands) so the plan works at
  home or in a simple gym.
- Keep the plan appropriate for age {age}. If the person is under 18, avoid maximal lifting
  and any calorie restriction advice.
- Plain text only. No Markdown, no tables, no emojis.

Format:
{PLAN_FORMAT}
"""
    return generate_text(
        model=config.GEMINI_PLAN_MODEL,
        prompt=prompt,
        system_instruction=SYSTEM_INSTRUCTION,
        temperature=0.7,
        max_output_tokens=8192,
    )
