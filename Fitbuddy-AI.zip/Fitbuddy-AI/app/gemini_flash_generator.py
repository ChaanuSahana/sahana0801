"""Nutrition / recovery tips (Gemini tip model, a fast lightweight model)."""
from typing import Optional

from . import config
from .gemini_client import generate_text

SYSTEM_INSTRUCTION = (
    "You are FitBuddy, a friendly fitness and nutrition coach. "
    "You give short, practical, safe tips in plain text without Markdown."
)

FALLBACK_TIPS = {
    "weight loss": "Fill half your plate with vegetables and include a protein source at every meal to stay full longer.",
    "muscle gain": "Include protein in your post-workout meal, such as eggs, chicken, fish, beans or Greek yogurt.",
    "general wellness": "Drink water through the day and aim for a colourful plate: vegetables, protein and whole grains.",
    "flexibility": "Stay hydrated and finish the day with 5 to 10 minutes of gentle stretching to help your muscles recover.",
    "endurance": "Eat some carbohydrates before long sessions and replace fluids and electrolytes afterwards.",
}


def generate_nutrition_tip_with_flash(
    goal: str, intensity: Optional[str] = None, previous_tip: Optional[str] = None
) -> str:
    """Return one concise nutrition or recovery tip for the user's goal."""
    extra = f"\nTheir workout intensity is {intensity}." if intensity else ""
    avoid = (
        f'\nDo not repeat this earlier tip, give a different one: "{previous_tip}"'
        if previous_tip
        else ""
    )
    prompt = f"""Give ONE nutrition or recovery tip for someone whose fitness goal is "{goal}".{extra}{avoid}

Rules:
- 2 or 3 sentences, at most 60 words.
- Practical and specific (a food, a habit or a recovery action).
- Plain text only. No Markdown, no lists, no emojis."""
    return generate_text(
        model=config.GEMINI_TIP_MODEL,
        prompt=prompt,
        system_instruction=SYSTEM_INSTRUCTION,
        temperature=0.9,
        max_output_tokens=2048,
    )
