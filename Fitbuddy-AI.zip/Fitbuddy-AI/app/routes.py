"""All HTTP routes: the HTML pages plus a small JSON API."""
import hashlib
import hmac
import logging
import re
from typing import List, Optional

from fastapi import APIRouter, Depends, Form, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError
from sqlalchemy.orm import Session

from . import config
from . import database as db_layer
from . import services
from .database import Plan, User, get_db
from .gemini_client import AIServiceError
from .schemas import (
    GOALS,
    INTENSITIES,
    FeedbackRequest,
    PlanResponse,
    UserInput,
    format_validation_errors,
)

logger = logging.getLogger("fitbuddy.routes")

router = APIRouter()
templates = Jinja2Templates(directory=str(config.TEMPLATE_DIR))

ADMIN_COOKIE = "fitbuddy_admin"


# ------------------------------------------------------- plan text parsing ---
_DAY_RE = re.compile(r"^\s*day\s*(\d+)\s*[:\-\u2013\u2014]?\s*(.*)$", re.IGNORECASE)
_NOTE_RE = re.compile(r"^\s*(safety note|note|disclaimer)\b", re.IGNORECASE)


def parse_plan(text: Optional[str]) -> dict:
    """Split plan text into day blocks for the result page. Falls back to the raw text."""
    days: List[dict] = []
    notes: List[str] = []
    current = None
    in_notes = False
    for line in (text or "").splitlines():
        match = _DAY_RE.match(line)
        if match and not in_notes:
            current = {
                "num": int(match.group(1)),
                "focus": match.group(2).strip(" -\u2013\u2014:"),
                "lines": [],
            }
            days.append(current)
            continue
        if _NOTE_RE.match(line):
            in_notes = True
            current = None
        if in_notes:
            notes.append(line)
        elif current is not None:
            current["lines"].append(line)
    for day in days:
        day["body"] = "\n".join(day.pop("lines")).strip()
    return {"days": days, "notes": "\n".join(notes).strip(), "raw": text or ""}


templates.env.filters["plan_days"] = parse_plan


# ------------------------------------------------------------ admin helpers ---
def _admin_token() -> str:
    return hmac.new(config.ADMIN_KEY.encode(), b"fitbuddy-admin-session", hashlib.sha256).hexdigest()


def _key_matches(candidate: Optional[str]) -> bool:
    if not config.ADMIN_KEY or not candidate:
        return False
    return hmac.compare_digest(candidate.encode(), config.ADMIN_KEY.encode())


def is_admin(request: Request) -> bool:
    cookie = request.cookies.get(ADMIN_COOKIE)
    if not config.ADMIN_KEY or not cookie:
        return False
    return hmac.compare_digest(cookie.encode(), _admin_token().encode())


def require_admin_api(request: Request, x_admin_key: Optional[str] = Header(default=None)) -> None:
    if is_admin(request) or _key_matches(x_admin_key):
        return
    raise HTTPException(status_code=401, detail="Admin key required (send it in the X-Admin-Key header).")


# ---------------------------------------------------------- render helpers ---
def _render_index(request: Request, form=None, errors=None, status_code: int = 200):
    context = {
        "form": form or {},
        "errors": errors or [],
        "goals": GOALS,
        "intensities": INTENSITIES,
    }
    return templates.TemplateResponse(request, "index.html", context, status_code=status_code)


def _render_result(
    request: Request,
    user: User,
    plan: Plan,
    message: Optional[str] = None,
    errors: Optional[List[str]] = None,
    status_code: int = 200,
):
    context = {
        "user": user,
        "username": user.username,
        "user_id": user.user_id,
        "age": user.age,
        "weight": user.weight,
        "goal": user.goal,
        "intensity": user.intensity,
        "workout_plan": plan.updated_plan or plan.original_plan,
        "original_plan": plan.original_plan,
        "updated": bool(plan.updated_plan),
        "nutrition_tip": plan.nutrition_tip,
        "message": message,
        "errors": errors or [],
    }
    return templates.TemplateResponse(request, "result.html", context, status_code=status_code)


def _render_feedback(request: Request, form=None, errors=None, status_code: int = 200):
    context = {"form": form or {}, "errors": errors or []}
    return templates.TemplateResponse(request, "feedback.html", context, status_code=status_code)


def _render_admin(
    request: Request, db: Session, errors=None, message: Optional[str] = None, status_code: int = 200
):
    admin = is_admin(request)
    context = {
        "is_admin": admin,
        "admin_configured": bool(config.ADMIN_KEY),
        "users": db_layer.get_all_users(db) if admin else [],
        "errors": errors or [],
        "message": message,
    }
    return templates.TemplateResponse(request, "all_users.html", context, status_code=status_code)


def _result_or_feedback_error(request: Request, db: Session, user_id: str, form: dict, errors: List[str], status_code: int):
    """Show an error on the plan page when the user exists, otherwise on the feedback page."""
    user = db_layer.get_user(db, user_id) if user_id else None
    plan = db_layer.get_plan(db, user_id) if user else None
    if user and plan:
        return _render_result(request, user, plan, errors=errors, status_code=status_code)
    return _render_feedback(request, form=form, errors=errors, status_code=status_code)


# ------------------------------------------------------------- HTML pages ---
@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return _render_index(request)


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(
    request: Request,
    username: str = Form(""),
    user_id: str = Form(""),
    age: str = Form(""),
    weight: str = Form(""),
    goal: str = Form(""),
    intensity: str = Form(""),
    db: Session = Depends(get_db),
):
    form = {
        "username": username,
        "user_id": user_id,
        "age": age,
        "weight": weight,
        "goal": goal,
        "intensity": intensity,
    }
    try:
        data = UserInput(**form)
    except ValidationError as exc:
        return _render_index(request, form=form, errors=format_validation_errors(exc), status_code=422)

    try:
        user, plan = services.create_workout_plan(db, data)
    except AIServiceError as exc:
        return _render_index(request, form=form, errors=[str(exc)], status_code=502)

    return _render_result(request, user, plan, message="Your 7-day plan is ready.")


@router.get("/feedback", response_class=HTMLResponse)
def feedback_page(request: Request, user_id: str = ""):
    return _render_feedback(request, form={"user_id": user_id})


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(
    request: Request,
    user_id: str = Form(""),
    feedback: str = Form(""),
    db: Session = Depends(get_db),
):
    form = {"user_id": user_id.strip(), "feedback": feedback}
    try:
        data = FeedbackRequest(**form)
    except ValidationError as exc:
        return _result_or_feedback_error(
            request, db, form["user_id"], form, format_validation_errors(exc), 422
        )

    try:
        user, plan = services.apply_feedback(db, data)
    except services.UserNotFoundError:
        return _render_feedback(
            request,
            form=form,
            errors=[f'No plan found for User ID "{data.user_id}". Create a plan on the home page first.'],
            status_code=404,
        )
    except AIServiceError as exc:
        return _result_or_feedback_error(request, db, data.user_id, form, [str(exc)], 502)

    return _render_result(request, user, plan, message="Your plan was updated based on your feedback.")


@router.post("/nutrition-tip", response_class=HTMLResponse)
def new_nutrition_tip(request: Request, user_id: str = Form(""), db: Session = Depends(get_db)):
    user_id = user_id.strip()
    try:
        user, plan = services.refresh_tip(db, user_id)
    except services.UserNotFoundError:
        return _render_feedback(
            request,
            form={"user_id": user_id},
            errors=[f'No plan found for User ID "{user_id}".'],
            status_code=404,
        )
    except AIServiceError as exc:
        return _result_or_feedback_error(request, db, user_id, {"user_id": user_id}, [str(exc)], 502)
    return _render_result(request, user, plan, message="Here is a new tip.")


# ----------------------------------------------------------------- admin ---
@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, db: Session = Depends(get_db)):
    return _render_admin(request, db, status_code=200 if is_admin(request) else 401)


@router.post("/admin-login")
def admin_login(request: Request, admin_key: str = Form(""), db: Session = Depends(get_db)):
    if not _key_matches(admin_key):
        return _render_admin(request, db, errors=["That admin key is not correct."], status_code=401)
    response = RedirectResponse(url="/view-all-users", status_code=303)
    response.set_cookie(
        ADMIN_COOKIE, _admin_token(), httponly=True, samesite="lax", max_age=60 * 60 * 8
    )
    return response


@router.post("/admin-logout")
def admin_logout():
    response = RedirectResponse(url="/", status_code=303)
    response.delete_cookie(ADMIN_COOKIE)
    return response


@router.post("/delete-user/{user_id}")
def delete_user(user_id: str, request: Request, db: Session = Depends(get_db)):
    if not is_admin(request):
        return RedirectResponse(url="/view-all-users", status_code=303)
    db_layer.delete_user(db, user_id)
    return RedirectResponse(url="/view-all-users", status_code=303)


# -------------------------------------------------------------- JSON API ---
@router.get("/health")
def health():
    return {"status": "ok", "ai_configured": bool(config.GOOGLE_API_KEY)}


@router.post("/api/generate-workout", response_model=PlanResponse)
def api_generate_workout(data: UserInput, db: Session = Depends(get_db)):
    try:
        user, plan = services.create_workout_plan(db, data)
    except AIServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    return services.to_plan_response(user, plan)


@router.post("/api/submit-feedback", response_model=PlanResponse)
def api_submit_feedback(data: FeedbackRequest, db: Session = Depends(get_db)):
    try:
        user, plan = services.apply_feedback(db, data)
    except services.UserNotFoundError:
        raise HTTPException(status_code=404, detail="No plan found for that user_id.")
    except AIServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    return services.to_plan_response(user, plan)


@router.get("/api/users", response_model=List[PlanResponse], dependencies=[Depends(require_admin_api)])
def api_users(db: Session = Depends(get_db)):
    return [
        services.to_plan_response(user, user.plan)
        for user in db_layer.get_all_users(db)
        if user.plan is not None
    ]
