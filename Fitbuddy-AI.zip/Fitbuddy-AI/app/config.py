"""Central configuration: reads the .env file once and exposes settings."""
import os
from pathlib import Path

from dotenv import load_dotenv

# Project root = the folder that contains /app, /templates and /static
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

TEMPLATE_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"
TEMPLATE_DIR.mkdir(exist_ok=True)
STATIC_DIR.mkdir(exist_ok=True)


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _resolve_database_url(url: str) -> str:
    """Make relative SQLite paths independent of the folder you start the server from."""
    prefix = "sqlite:///"
    if url.startswith(prefix) and not url.startswith("sqlite:////"):
        target = url[len(prefix):]
        if target and target != ":memory:" and not os.path.isabs(target):
            return f"{prefix}{(BASE_DIR / target).as_posix()}"
    return url


GOOGLE_API_KEY = _env("GOOGLE_API_KEY") or _env("GEMINI_API_KEY")
GEMINI_PLAN_MODEL = _env("GEMINI_PLAN_MODEL", "gemini-2.5-flash")
GEMINI_TIP_MODEL = _env("GEMINI_TIP_MODEL", "gemini-2.5-flash")
ADMIN_KEY = _env("ADMIN_KEY")
DATABASE_URL = _resolve_database_url(_env("DATABASE_URL", "sqlite:///./fitbuddy.db"))

DEFAULT_ADMIN_KEY = "change-this-to-a-private-password"
