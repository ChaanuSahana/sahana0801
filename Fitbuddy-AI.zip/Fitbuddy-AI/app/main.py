"""FitBuddy application entry point (run with: uvicorn app.main:app --reload)."""
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from . import config
from .database import init_db
from .routes import router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("fitbuddy")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    if not config.GOOGLE_API_KEY:
        logger.warning("GOOGLE_API_KEY is not set. Add it to .env, save the file and restart.")
    if not config.ADMIN_KEY:
        logger.warning("ADMIN_KEY is not set, so the admin dashboard is disabled.")
    elif config.ADMIN_KEY == config.DEFAULT_ADMIN_KEY:
        logger.warning("ADMIN_KEY still has the placeholder value. Change it in .env.")
    yield


app = FastAPI(
    title="FitBuddy - AI Fitness Plan Generator",
    description="Personalised 7-day workout plans and nutrition tips powered by Google Gemini.",
    lifespan=lifespan,
)
app.mount("/static", StaticFiles(directory=str(config.STATIC_DIR)), name="static")
app.include_router(router)
