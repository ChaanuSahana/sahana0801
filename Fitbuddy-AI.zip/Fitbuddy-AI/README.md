# FitBuddy - AI Fitness Plan Generator

FastAPI + Google Gemini + SQLite + Jinja2. Generates a personalised 7-day workout plan and a nutrition tip,
updates the plan from user feedback, and gives admins a dashboard of all users and plans.

## Project structure

```
Fitbuddy-AI/
├── main.py                      # shortcut entry point (python main.py / uvicorn main:app)
├── requirements.txt
├── .env                         # YOUR secrets (create from .env.example, never share or commit)
├── .env.example
├── .gitignore
├── .vscode/                     # VS Code interpreter + debug settings
├── app/
│   ├── main.py                  # FastAPI app, static files, startup checks
│   ├── config.py                # reads .env
│   ├── database.py              # SQLAlchemy models + save_user, save_plan, update_plan, get_*...
│   ├── schemas.py               # UserInput, FeedbackRequest (Pydantic validation)
│   ├── gemini_client.py         # one Gemini client, retries, friendly errors, text clean-up
│   ├── gemini_generator.py      # generate_workout_gemini()
│   ├── gemini_flash_generator.py# generate_nutrition_tip_with_flash()
│   ├── updated_plan.py          # update_workout_plan()
│   ├── services.py              # logic shared by HTML pages and JSON API
│   └── routes.py                # all routes
├── templates/                   # index.html, result.html, feedback.html, all_users.html, base.html
└── static/                      # css/style.css, images/gym-bg.svg
```

## Setup on Windows (VS Code)

1. Install Python 3.12 or 3.13 from python.org and tick **Add python.exe to PATH**
   (3.14 works only if every package has a 3.14 build; if `pip install` fails, use 3.12/3.13).
2. Open the `Fitbuddy-AI` folder in VS Code (File > Open Folder).
3. Open a terminal (Ctrl+`) and run:

   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

   If activation is blocked: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, then activate again.
4. Create `.env` (copy `.env.example`), paste your Gemini key, and **save the file (Ctrl+S)**.
5. In VS Code press Ctrl+Shift+P > "Python: Select Interpreter" > choose `.\venv\Scripts\python.exe`.
6. Start the server:

   ```powershell
   uvicorn app.main:app --reload
   ```

   (`python main.py` and `uvicorn main:app --reload` also work.)
7. Open http://127.0.0.1:8000 (app) and http://127.0.0.1:8000/docs (API docs).
   Press F5 in VS Code to run with the debugger instead.

## Settings (.env)

| Variable | Meaning |
|---|---|
| `GOOGLE_API_KEY` | Gemini API key from https://aistudio.google.com/apikey |
| `GEMINI_PLAN_MODEL` | Model for plans and feedback updates (default `gemini-2.5-flash`) |
| `GEMINI_TIP_MODEL` | Model for nutrition tips (default `gemini-2.5-flash`) |
| `ADMIN_KEY` | Password for the admin dashboard |
| `DATABASE_URL` | Default `sqlite:///./fitbuddy.db` (file is created in the project folder) |

You can set `GEMINI_PLAN_MODEL` to a more capable model such as `gemini-2.5-pro` for richer plans
(slower, and it may have stricter free-tier limits).

## Using the app

| Page | What it does |
|---|---|
| `/` | Enter name, User ID, age, weight, goal and intensity, then "Generate plan" |
| result page | 7-day plan by day, nutrition tip ("Show another tip"), feedback form |
| `/feedback` | Update an existing plan by User ID (e.g. "include more rest days") |
| `/view-all-users` | Admin dashboard: sign in with `ADMIN_KEY`, see every user, original and updated plans, delete users |

Submitting the same User ID again replaces that user's details and plan with a new one.
Feedback keeps the original plan and stores the revision next to it; further feedback builds on the latest revision.

## JSON API

```powershell
# create a plan
curl -X POST http://127.0.0.1:8000/api/generate-workout -H "Content-Type: application/json" `
  -d '{\"username\":\"Asha\",\"user_id\":\"asha1\",\"age\":28,\"weight\":62,\"goal\":\"muscle gain\",\"intensity\":\"medium\"}'

# update it
curl -X POST http://127.0.0.1:8000/api/submit-feedback -H "Content-Type: application/json" `
  -d '{\"user_id\":\"asha1\",\"feedback\":\"more focus on cardio\"}'

# list users (admin)
curl http://127.0.0.1:8000/api/users -H "X-Admin-Key: <your ADMIN_KEY>"
```

Or try them in the interactive docs at `/docs`. `GET /health` shows whether a key is configured.

## Troubleshooting

| Problem | Fix |
|---|---|
| `Python was not found` | Reinstall Python with "Add python.exe to PATH", reopen VS Code |
| "The Gemini API key is missing" | Add `GOOGLE_API_KEY` to `.env`, **save**, restart the server |
| "Gemini rejected the API key" | Key is wrong or revoked: create a new one in Google AI Studio |
| "could not find the configured model" | Fix the model names in `.env` |
| "usage limit was reached" | Free-tier quota: wait a minute, or use a smaller model |
| Port 8000 in use | `uvicorn app.main:app --reload --port 8001` |
| Odd errors inside `venv` | OneDrive can lock files: keep the project outside OneDrive |
| Admin page says "turned off" | Set `ADMIN_KEY` in `.env` and restart |

## Notes

- The original brief names Gemini 1.5 Pro and the `google-generativeai` package. Gemini 1.5 models have been
  retired and that SDK is deprecated, so this project uses the current `google-genai` SDK and the models set in `.env`.
- If the tip model fails, the app shows a built-in tip so the plan is never lost.
- Never commit `.env`. If a key is ever shared or posted, revoke it and create a new one.
- FitBuddy gives general fitness guidance, not medical advice.
